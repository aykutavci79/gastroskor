// scripts/import_stories_3lang.js
/* eslint-disable no-console */
const fs = require("fs");
const path = require("path");
const Database = require("better-sqlite3");

function readJson(p) {
  const raw = fs.readFileSync(p, "utf8");
  const data = JSON.parse(raw);
  if (!Array.isArray(data)) throw new Error(`${p} must be a JSON array`);
  return data;
}

function slugify(input) {
  return String(input || "")
    .trim()
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/ı/g, "i")
    .replace(/ğ/g, "g")
    .replace(/ş/g, "s")
    .replace(/ç/g, "c")
    .replace(/ö/g, "o")
    .replace(/ü/g, "u")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function pickExistingColumn(existingColsSet, candidates) {
  return candidates.find((c) => existingColsSet.has(c)) || null;
}

function buildUpsertSQL(tableName, insertCols, conflictCols, updateCols) {
  const colsSql = insertCols.map((c) => `"${c}"`).join(", ");
  const valsSql = insertCols.map((c) => `@${c}`).join(", ");

  if (!conflictCols || conflictCols.length === 0) {
    return `INSERT INTO "${tableName}" (${colsSql}) VALUES (${valsSql})`;
  }

  const conflictSql = conflictCols.map((c) => `"${c}"`).join(", ");
  const setSql = updateCols.map((c) => `"${c}"=excluded."${c}"`).join(", ");

  return `
    INSERT INTO "${tableName}" (${colsSql})
    VALUES (${valsSql})
    ON CONFLICT (${conflictSql})
    DO UPDATE SET ${setSql}
  `.trim();
}

function nowIso() {
  return new Date().toISOString();
}

function main() {
  const projectRoot = path.join(__dirname, "..");
  const dbPath = process.env.SQLITE_PATH || path.join(projectRoot, "dev.db");
  const seedsDir = process.env.SEEDS_DIR || path.join(projectRoot, "seeds");

  const files = [
    { lang: "tr", file: path.join(seedsDir, "stories_seed_tr.json") },
    { lang: "en", file: path.join(seedsDir, "stories_seed_en.json") },
    { lang: "fr", file: path.join(seedsDir, "stories_seed_fr.json") }
  ];

  const db = new Database(dbPath);
  db.pragma("journal_mode = WAL");

  const tableInfo = db.prepare(`PRAGMA table_info('Story')`).all();
  if (!tableInfo || tableInfo.length === 0) {
    throw new Error(`Table 'Story' not found (or has no columns).`);
  }
  const existingCols = new Set(tableInfo.map((c) => c.name));

  // Candidates (schema-agnostic)
  const colKey = pickExistingColumn(existingCols, ["key", "storyKey", "code", "uid"]);
  const colLang = pickExistingColumn(existingCols, ["lang", "language", "locale"]);
  const colSlug = pickExistingColumn(existingCols, ["slug", "permalink"]);
  const colTitle = pickExistingColumn(existingCols, ["title", "name", "headline"]);
  const colContent = pickExistingColumn(existingCols, ["content", "body", "text", "story"]);
  const colCreatedAt = pickExistingColumn(existingCols, ["createdAt", "created_at"]);
  const colUpdatedAt = pickExistingColumn(existingCols, ["updatedAt", "updated_at"]);

  let conflictCols = [];
  if (colKey && colLang) conflictCols = [colKey, colLang];
  else if (colSlug && colLang) conflictCols = [colSlug, colLang];
  else if (colKey) conflictCols = [colKey];
  else if (colSlug) conflictCols = [colSlug];

  // Try to create unique index for upsert
  try {
    if (conflictCols.length === 2) {
      db.exec(
        `CREATE UNIQUE INDEX IF NOT EXISTS idx_story_${conflictCols[0]}_${conflictCols[1]}
         ON Story("${conflictCols[0]}", "${conflictCols[1]}")`
      );
    } else if (conflictCols.length === 1) {
      db.exec(
        `CREATE UNIQUE INDEX IF NOT EXISTS idx_story_${conflictCols[0]}
         ON Story("${conflictCols[0]}")`
      );
    }
  } catch (e) {
    console.warn("Index create warning:", e.message);
  }

  const insertCols = [];
  const maybePush = (col) => { if (col && existingCols.has(col)) insertCols.push(col); };
  maybePush(colKey);
  maybePush(colLang);
  maybePush(colSlug);
  maybePush(colTitle);
  maybePush(colContent);
  maybePush(colCreatedAt);
  maybePush(colUpdatedAt);

  const updateCols = insertCols.filter((c) => !conflictCols.includes(c));
  const sql = buildUpsertSQL("Story", insertCols, conflictCols, updateCols);
  const stmt = db.prepare(sql);

  const tx = db.transaction(() => {
    let affected = 0;

    for (const { lang, file } of files) {
      const stories = readJson(file);

      for (const s of stories) {
        const keyVal = s.key;
        const titleVal = s.title || "";
        const contentVal = s.content || "";
        const slugVal = s.slug ? String(s.slug) : slugify(titleVal || keyVal);

        const row = {};
        if (colKey) row[colKey] = String(keyVal);
        if (colLang) row[colLang] = lang;
        if (colSlug) row[colSlug] = slugVal;
        if (colTitle) row[colTitle] = String(titleVal);
        if (colContent) row[colContent] = String(contentVal);
        if (colCreatedAt) row[colCreatedAt] = nowIso();
        if (colUpdatedAt) row[colUpdatedAt] = nowIso();

        stmt.run(row);
        affected++;
      }
      console.log(`✓ ${lang.toUpperCase()} imported: ${stories.length} items`);
    }
    return affected;
  });

  const affected = tx();
  const total = db.prepare(`SELECT COUNT(*) as c FROM Story`).get().c;
  console.log(`\nDONE. rows upserted/inserted: ${affected}`);
  console.log(`Story TOTAL in dev.db: ${total}\n`);

  db.close();
}

main();
